document.addEventListener('DOMContentLoaded', () => {
  lucide.createIcons();
});
